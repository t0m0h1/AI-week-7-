This repo is to share lab tasks with students to learn about AI and Machine Learning
